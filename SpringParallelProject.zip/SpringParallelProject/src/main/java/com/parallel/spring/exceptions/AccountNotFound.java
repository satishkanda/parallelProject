package com.parallel.spring.exceptions;

public class AccountNotFound extends Exception {
	public AccountNotFound(String message)
	{
		super(message);
	}

}
