package com.parallel.spring.service;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.parallel.spring.beans.Account;
import com.parallel.spring.beans.Transaction;
import com.parallel.spring.dao.AccountDao;

import com.parallel.spring.dao.TransactionDao;
import com.parallel.spring.exceptions.AccountMismatchException;
import com.parallel.spring.exceptions.AccountNotFound;
import com.parallel.spring.exceptions.InvalidAmountException;

@Service
public class BankServiceImpl implements BankService {
	static Scanner sc = new Scanner(System.in);

	public java.sql.Date getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Date(today.getTime());
	}

	@Autowired
	private AccountDao accountDao;

	@Autowired
	private TransactionDao transactionDao;

	@Override
	public List<Account> createAcccount(Account account) {
		accountDao.save(account);
		return getAllAccounts();

	}

	@Override
	public List<Account> getAllAccounts() {
		return accountDao.findAll();

	}

	@Override
	public List<Account> deposit(int accno, double amount) throws InvalidAmountException, AccountNotFound {
		if (accountDao.existsById(accno)) {
			Account account = accountDao.findById(accno).get();

			if (amount > 0) {
				account.setInitialbalance(account.getInitialbalance() + amount);
			} else {
				throw new InvalidAmountException("Amount should be greater than zero");
			}
			accountDao.save(account);
			Transaction transaction = new Transaction("CR", "Deposited", amount);
			java.sql.Date date1 = getCurrentDate();
			transaction.setDate1(date1);
			transaction.setAccount(account);
			transactionDao.save(transaction);

		} else {
			throw new AccountNotFound("Account not Found");
		}
		return getAllAccounts();
	}

	@Override
	public List<Account> withdraw(int accno, double amount) throws InvalidAmountException, AccountNotFound {
		if (accountDao.existsById(accno)) {
			Account account = accountDao.findById(accno).get();
			double initialbalnce = account.getInitialbalance();
			if(amount<=0)
			{
				throw new InvalidAmountException("Amount should be greater than zero" );
			}
			else
			{
			if (amount <= initialbalnce ) {
				account.setInitialbalance(account.getInitialbalance() - amount);
			} else {
				throw new InvalidAmountException("Withdrawl amount  is greater than BankBalance");
			}
			accountDao.save(account);
			Transaction transaction = new Transaction("DR", "Debited", amount);
			java.sql.Date date1 = getCurrentDate();
			transaction.setDate1(date1);
			transaction.setAccount(account);
			transactionDao.save(transaction);
		}
		} else {
			throw new AccountNotFound("Account not Found");
		}
		return getAllAccounts();
	}

	@Override
	public List<Account> fundsTransfer(int accno1, int accno2, double amount)
			throws AccountMismatchException, InvalidAmountException, AccountNotFound {
		if (accountDao.existsById(accno1) && accountDao.existsById(accno2)) {

			if (accno1 == accno2) {
				throw new AccountMismatchException("Transfer to same Account will not Done");
			} else {
				Account a1 = accountDao.findById(accno1).get();
				Account a2 = accountDao.findById(accno2).get();
				double initialbalnce1 = a1.getInitialbalance();
				if (amount <= initialbalnce1 && amount > 0) {
					a1.setInitialbalance(a1.getInitialbalance() - amount);
					a2.setInitialbalance(a2.getInitialbalance() + amount);
				} else {
					throw new InvalidAmountException("Transfer amount is greater than Account balance");
				}

				accountDao.save(a1);
				accountDao.save(a2);
				Transaction transaction1 = new Transaction("DR", "Debited", amount);
				java.sql.Date date1 = getCurrentDate();
				transaction1.setDate1(date1);
				transaction1.setAccount(a1);
				transactionDao.save(transaction1);
				Transaction transaction2 = new Transaction("CR", "Deposited", amount);
				java.sql.Date date2 = getCurrentDate();
				transaction2.setDate1(date2);
				transaction2.setAccount(a2);
				transactionDao.save(transaction2);
			}

		} else {
			throw new AccountNotFound("Account not found enter valid Account numbers");
		}
		return getAllAccounts();

	}

	@Override
	public List<Transaction> getAllTransactions() {

		return transactionDao.findAll();
	}

	@Override
	public double getInitialBalance(int accno) throws AccountNotFound {
		if(accountDao.existsById(accno))
		{
			
			return accountDao.findById(accno).get().getInitialbalance();
		}
		else
		{
			throw new AccountNotFound("Account with no="+accno+" not Found");
		}

	}

	@Override
	public List<Transaction> getTransactionByAccno(int accno) {
		
		return transactionDao.getTransactionByAccno(accno);
	}

	@Override
	public Account getAccountByNo(int accno) throws AccountNotFound {
		if(accountDao.existsById(accno))
		{
			
			return accountDao.findById(accno).get();
		}
		else
		{
			throw new AccountNotFound("Account with no="+accno+" not Found");
		}
	}

}
