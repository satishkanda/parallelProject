export interface Transaction {
    trans_Id: number;
    type: String;
    description: String;
    amount: number;
    date1: Date;
    account:Account
}