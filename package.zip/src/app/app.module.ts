import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateAccountComponent } from './bank/create-account/create-account.component';

import { HomeComponent } from './bank/home/home.component';
import { ShowAccountsComponent } from './bank/show-accounts/show-accounts.component';
import { OperationsComponent } from './bank/operations/operations.component';
import { DepositComponent } from './bank/deposit/deposit.component';
import { TransactionListComponent } from './bank/transaction-list/transaction-list.component';
import { WithdrawComponent } from './bank/withdraw/withdraw.component';
import { FundsTransferComponent } from './bank/funds-transfer/funds-transfer.component';
import { GetAccountComponent } from './bank/get-account/get-account.component';


@NgModule({
  declarations: [
    AppComponent,
    CreateAccountComponent,
    HomeComponent,
    ShowAccountsComponent,
    OperationsComponent,
    DepositComponent,
    TransactionListComponent,
    WithdrawComponent,
    FundsTransferComponent,
    GetAccountComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
